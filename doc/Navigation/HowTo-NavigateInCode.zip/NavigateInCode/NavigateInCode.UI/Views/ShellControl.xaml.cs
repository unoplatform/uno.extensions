﻿
namespace NavigateInCode.Views;
public sealed partial class ShellControl : UserControl
{
    public ShellControl()
    {
        this.InitializeComponent();
    }
}
