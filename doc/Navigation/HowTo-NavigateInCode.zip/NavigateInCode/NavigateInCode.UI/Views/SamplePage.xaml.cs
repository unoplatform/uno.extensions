﻿namespace NavigateInCode.Views
{
    public sealed partial class SamplePage : Page
    {
        public SampleViewModel? ViewModel { get; private set; }

        public SamplePage()
        {
            this.InitializeComponent();

            DataContextChanged += (_, changeArgs) => ViewModel = changeArgs.NewValue as SampleViewModel;
        }

        private void GoBackClick(object sender, RoutedEventArgs e)
        {
            _ = this.Navigator()?.NavigateBackAsync(this);
        }
    }
}
