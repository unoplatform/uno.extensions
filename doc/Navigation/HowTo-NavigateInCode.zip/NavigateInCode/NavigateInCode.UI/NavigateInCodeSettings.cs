using System;
using System.Collections.Generic;
using System.Text;

namespace NavigateInCode
{
    public record NavigateInCodeSettings
    {
        public string? LastSearch { get; init; }
    }
}
