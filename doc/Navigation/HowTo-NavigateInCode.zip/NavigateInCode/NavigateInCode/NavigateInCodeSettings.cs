
namespace NavigateInCode;

public record NavigateInCodeSettings
{
	public string? LastSearch { get; init; }
}
