
namespace NavigateInCode;

public record AppInfo
{
	public string? Title { get; init; }
}
