using AppKit;
using Foundation;

namespace NavigateInCode.macOS
{

}
