﻿
namespace NavigateBetweenPages.ViewModels;

public class SampleViewModel
{
	public string Title => "Sample Page";

    private readonly INavigator _navigator;
    public SampleViewModel(INavigator navigator)
    {
        _navigator = navigator;
    }
    public Task GoBack()
    {
        return _navigator.NavigateBackAsync(this);
    }
}
