
namespace NavigateBetweenPages.ViewModels;
public class SecondViewModel
{
	
	public SecondViewModel()
	{
	}
}
