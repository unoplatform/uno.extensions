
namespace NavigateBetweenPages;

public record AppInfo
{
	public string? Title { get; init; }
}
