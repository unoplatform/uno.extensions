
namespace NavigateBetweenPages;

public record NavigateBetweenPagesSettings
{
	public string? LastSearch { get; init; }
}
