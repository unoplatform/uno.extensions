using System;
using System.Collections.Generic;
using System.Text;

namespace NavigateBetweenPages
{
    public record NavigateBetweenPagesSettings
    {
        public string? LastSearch { get; init; }
    }
}
