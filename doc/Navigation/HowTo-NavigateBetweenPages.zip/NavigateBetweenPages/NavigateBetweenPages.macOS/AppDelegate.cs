using AppKit;
using Foundation;

namespace NavigateBetweenPages.macOS
{

}
