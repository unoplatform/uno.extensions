using AppKit;
using Foundation;

namespace DisplayMessageDialog.macOS
{

}
