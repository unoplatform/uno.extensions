using System;
using System.Collections.Generic;
using System.Text;

namespace DisplayMessageDialog
{
    public record DisplayMessageDialogSettings
    {
        public string? LastSearch { get; init; }
    }
}
