﻿
namespace DisplayMessageDialog.Views;

public sealed partial class SecondPage : Page
{
    public SecondPage()
    {
        this.InitializeComponent();
    }
}

