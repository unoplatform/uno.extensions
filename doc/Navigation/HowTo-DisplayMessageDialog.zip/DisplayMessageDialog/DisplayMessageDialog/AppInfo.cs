
namespace DisplayMessageDialog;

public record AppInfo
{
	public string? Title { get; init; }
}
