
namespace DisplayMessageDialog;

public record DisplayMessageDialogSettings
{
	public string? LastSearch { get; init; }
}
