
namespace DisplayMessageDialog.ViewModels;
public class SecondViewModel
{
	
	public SecondViewModel()
	{
	}
}
