using Microsoft.Extensions.Options;

namespace DisplayMessageDialog.ViewModels;

public class MainViewModel
{
    public string? Title { get; }

    public MainViewModel(
        INavigator navigator,
        IOptions<AppInfo> appInfo) 
    {

        _navigator = navigator;
        Title = appInfo?.Value?.Title;
    }

    public async Task GoToSecondPage()
    {
        await _navigator.NavigateViewModelAsync<SecondViewModel>(this);
    }

    public async Task ShowSimpleDialog()
    {
        //_= _navigator.ShowMessageDialogAsync(this, content: "Hello Uno Extensions!");

        //var result = await _navigator.ShowMessageDialogAsync<string>(this, content: "Hello Uno Extensions!").AsResult();

        //  var result = await _navigator.ShowMessageDialogAsync<string>(this,
        //content: "Hello Uno Extensions!",
        //commands: new[]
        //{
        //new DialogAction("Ok"),
        //new DialogAction("Cancel")
        //}).AsResult();

        //var result = await _navigator.ShowMessageDialogAsync<string>(this, route: "MyMessage");


        var result = await _navigator.ShowMessageDialogAsync<string>(this, route: "MyLocalizedMessage");

    }


    private INavigator _navigator;
}
