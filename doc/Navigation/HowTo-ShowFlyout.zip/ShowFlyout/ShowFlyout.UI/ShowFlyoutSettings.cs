using System;
using System.Collections.Generic;
using System.Text;

namespace ShowFlyout
{
    public record ShowFlyoutSettings
    {
        public string? LastSearch { get; init; }
    }
}
