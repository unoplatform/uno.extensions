
namespace ShowFlyout.ViewModels;
public class SecondViewModel
{
	
	public SecondViewModel()
	{
	}
}
