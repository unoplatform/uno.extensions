
namespace ShowFlyout;

public record AppInfo
{
	public string? Title { get; init; }
}
