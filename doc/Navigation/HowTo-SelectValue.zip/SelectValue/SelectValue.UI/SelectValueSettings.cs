using System;
using System.Collections.Generic;
using System.Text;

namespace SelectValue
{
    public record SelectValueSettings
    {
        public string? LastSearch { get; init; }
    }
}
