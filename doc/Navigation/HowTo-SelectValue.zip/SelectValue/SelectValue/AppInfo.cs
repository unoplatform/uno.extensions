
namespace SelectValue;

public record AppInfo
{
	public string? Title { get; init; }
}
