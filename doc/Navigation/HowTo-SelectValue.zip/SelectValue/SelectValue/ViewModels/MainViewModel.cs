
using Microsoft.Extensions.Options;

namespace SelectValue.ViewModels;

public class MainViewModel
{
	public string? Title { get; }

	public MainViewModel(
		INavigator navigator,
		IOptions<AppInfo> appInfo)
	{ 
	
		_navigator = navigator;
		Title = appInfo?.Value?.Title;
	}

	public async Task GoToSecondPage()
	{
		var widget= await _navigator.NavigateViewModelForResultAsync<SecondViewModel, Widget>(this).AsResult();
	}

	private INavigator _navigator;
}


public record Widget(string Name, double Weight) { }