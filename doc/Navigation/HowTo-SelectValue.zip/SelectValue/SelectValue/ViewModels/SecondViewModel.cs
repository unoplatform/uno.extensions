
namespace SelectValue.ViewModels;
public class SecondViewModel
{
    public Widget[] Widgets { get; } = new[]
                    {
                        new Widget("NormalSpinner", 5.0),
                        new Widget("HeavySpinner",50.0)
                    };

    public SecondViewModel()
    {
    }
}
