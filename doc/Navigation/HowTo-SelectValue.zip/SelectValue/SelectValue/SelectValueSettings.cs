
namespace SelectValue;

public record SelectValueSettings
{
	public string? LastSearch { get; init; }
}
