using AppKit;
using Foundation;

namespace SelectValue.macOS
{

}
