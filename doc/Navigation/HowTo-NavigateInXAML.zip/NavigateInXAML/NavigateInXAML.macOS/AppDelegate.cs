using AppKit;
using Foundation;

namespace NavigateInXAML.macOS
{

}
