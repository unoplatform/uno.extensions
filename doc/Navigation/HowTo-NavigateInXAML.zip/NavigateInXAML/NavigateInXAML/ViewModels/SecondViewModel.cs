
namespace NavigateInXAML.ViewModels;
public class SecondViewModel
{
	
	public SecondViewModel()
	{
	}
}

public class SampleViewModel
{
    public string Title => "Sample Page";
    private readonly INavigator _navigator;

    public string Name { get; }

    public SampleViewModel(INavigator navigator, Widget widget)
    {
        _navigator = navigator;
        Name = widget.Name;
    }
}
