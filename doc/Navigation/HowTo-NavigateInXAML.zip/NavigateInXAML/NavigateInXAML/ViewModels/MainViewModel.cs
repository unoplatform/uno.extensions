
using Microsoft.Extensions.Options;

namespace NavigateInXAML.ViewModels;

public class MainViewModel
{
	public string? Title { get; }

    public Widget[] Widgets { get; } = new[]
{
    new Widget("NormalSpinner", 5.0),
    new Widget("HeavySpinner",50.0)
};

    public MainViewModel(
		INavigator navigator,
		IOptions<AppInfo> appInfo)
	{ 
	
		_navigator = navigator;
		Title = appInfo?.Value?.Title;
	}

	public async Task GoToSecondPage()
	{
		await _navigator.NavigateViewModelAsync<SecondViewModel>(this);
	}

	private INavigator _navigator;
}


public record Widget(string Name, double Weight) { }
