
namespace NavigateInXAML;

public record AppInfo
{
	public string? Title { get; init; }
}
