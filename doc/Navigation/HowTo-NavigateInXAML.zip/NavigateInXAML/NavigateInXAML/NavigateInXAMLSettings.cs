
namespace NavigateInXAML;

public record NavigateInXAMLSettings
{
	public string? LastSearch { get; init; }
}
