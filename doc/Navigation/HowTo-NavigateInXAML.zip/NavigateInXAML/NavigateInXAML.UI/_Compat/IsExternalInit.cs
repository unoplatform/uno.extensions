using System;
using System.Linq;

#if !NET5_0
namespace System.Runtime.CompilerServices;

internal static class IsExternalInit
{
}
#endif
