using System;
using System.Collections.Generic;
using System.Text;

namespace NavigateInXAML
{
    public record NavigateInXAMLSettings
    {
        public string? LastSearch { get; init; }
    }
}
