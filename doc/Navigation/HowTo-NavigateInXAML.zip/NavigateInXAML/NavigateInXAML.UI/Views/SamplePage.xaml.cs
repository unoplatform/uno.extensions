﻿
namespace NavigateInXAML.Views;

public sealed partial class SamplePage : Page
{
    public SamplePage()
    {
        this.InitializeComponent();
    }
}
