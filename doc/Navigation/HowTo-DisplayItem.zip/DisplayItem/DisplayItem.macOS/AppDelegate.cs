using AppKit;
using Foundation;

namespace DisplayItem.macOS
{

}
