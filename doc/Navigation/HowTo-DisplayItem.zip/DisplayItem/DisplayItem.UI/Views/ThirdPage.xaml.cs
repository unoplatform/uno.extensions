﻿
namespace DisplayItem.Views;

public sealed partial class ThirdPage : Page
{
    public ThirdPage()
    {
        this.InitializeComponent();
    }
}

