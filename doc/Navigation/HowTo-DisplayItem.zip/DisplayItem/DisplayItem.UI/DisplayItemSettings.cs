using System;
using System.Collections.Generic;
using System.Text;

namespace DisplayItem
{
    public record DisplayItemSettings
    {
        public string? LastSearch { get; init; }
    }
}
