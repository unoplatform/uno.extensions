
namespace DisplayItem;

public record DisplayItemSettings
{
	public string? LastSearch { get; init; }
}
