
namespace DisplayItem;

public record AppInfo
{
	public string? Title { get; init; }
}
