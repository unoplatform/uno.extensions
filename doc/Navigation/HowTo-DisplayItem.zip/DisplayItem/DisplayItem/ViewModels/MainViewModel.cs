
using Microsoft.Extensions.Options;

namespace DisplayItem.ViewModels;

public class MainViewModel
{
    public string? Title { get; }

    public Widget[] Widgets { get; } = new Widget[]
    {
        new BasicWidget("NormalSpinner", 5.0),
        new AdvancedWidget("HeavySpinner",50.0)
    };

    public MainViewModel(
        INavigator navigator,
        IOptions<AppInfo> appInfo)
    {

        _navigator = navigator;
        Title = appInfo?.Value?.Title;
    }

    public async Task GoToSecondPage()
    {
        var widget = new Widget("CrazySpinner", 34.0);

        await _navigator.NavigateDataAsync(this, data: widget);
    }

    private INavigator _navigator;
}

public record Widget(string Name, double Weight) { }

public record BasicWidget(string Name, double Weight) : Widget(Name, Weight) { }

public record AdvancedWidget(string Name, double Weight) : Widget(Name, Weight) { }
