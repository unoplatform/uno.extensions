
namespace DisplayItem.ViewModels;
public class SecondViewModel
{
    public string Name { get; }
    
    public SecondViewModel(BasicWidget widget)
	{
        Name = widget.Name; 
	}
}
public class ThirdViewModel
{
    public string Name { get; }
    
    public ThirdViewModel(AdvancedWidget widget)
	{
        Name = widget.Name; 
	}
}