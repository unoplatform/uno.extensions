
namespace $safeprojectname$.Business.Models;

public record AppConfig
{
	public string? Title { get; init; }
}
