
namespace $safeprojectname$.Business.Models;

public record Entity(string Name);
