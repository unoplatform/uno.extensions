
namespace $safeprojectname$.Presentation;

public partial record SecondModel (Entity Entity)
{
}
