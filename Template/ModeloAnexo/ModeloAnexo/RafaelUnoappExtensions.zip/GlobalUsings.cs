﻿global using System.Threading;
global using System.Threading.Tasks;
global using Microsoft.Extensions.Options;
global using $safeprojectname$.Business.Models;
global using $safeprojectname$.Presentation;
global using Uno.Extensions.Navigation;
